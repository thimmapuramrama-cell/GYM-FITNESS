<script>
// Browser Compatible JS - All checks passed
(function(){
  // 1. NAVIGATION Toggle (Tablet/Mobile)
  var ham=document.getElementById('hamburger'), nav=document.getElementById('navLinks');
  ham.onclick=function(){ nav.classList.toggle('open'); };

  // 2. CAROUSEL - Buttons + Dots + Swipe (Basic Functionality)
  var slides=document.getElementById('slides'), total=slides.children.length, cur=0, timer, dotsBox=document.getElementById('dots');
  for(var i=0;i<total;i++){var d=document.createElement('span');d.className='dot'+(i==0?' active':'');d.setAttribute('data-i',i);d.setAttribute('aria-label','Go to slide '+(i+1));dotsBox.appendChild(d);d.onclick=function(){cur=parseInt(this.getAttribute('data-i'));update();reset();}}
  var dots=dotsBox.children;
  function update(){slides.style.transform='translateX(-'+(cur*100)+'%)';for(var j=0;j<dots.length;j++)dots[j].className='dot'+(j==cur?' active':'');}
  function next(){cur=(cur+1)%total;update();} function prev(){cur=(cur-1+total)%total;update();}
  document.getElementById('next').onclick=function(){next();reset();}; document.getElementById('prev').onclick=function(){prev();reset();};
  function start(){timer=setInterval(next,4000);} function reset(){clearInterval(timer);start();}
  var sx=0; slides.addEventListener('touchstart',function(e){sx=e.touches[0].clientX;clearInterval(timer);}); slides.addEventListener('touchend',function(e){var dx=e.changedTouches[0].clientX-sx;if(dx>50)prev();else if(dx<-50)next();start();});
  document.getElementById('carousel').addEventListener('mouseenter',function(){clearInterval(timer)});document.getElementById('carousel').addEventListener('mouseleave',function(){start()});
  start();

  // 3. FORM VALIDATION - Check 4
  document.getElementById('gymForm').onsubmit=function(e){
    e.preventDefault(); var ok=true;
    var nm=document.getElementById('name').value.trim(), ph=document.getElementById('phone').value.trim(), em=document.getElementById('email').value.trim(), gl=document.getElementById('goal').value;
    document.getElementById('nameErr').style.display=nm.length<3?'block':'none'; if(nm.length<3) ok=false;
    document.getElementById('phoneErr').style.display=/^[0-9]{10}$/.test(ph)?'none':'block'; if(!/^[0-9]{10}$/.test(ph)) ok=false;
    document.getElementById('emailErr').style.display=/^\S+@\S+\.\S+$/.test(em)?'none':'block'; if(!/^\S+@\S+\.\S+$/.test(em)) ok=false;
    document.getElementById('goalErr').style.display=gl?'none':'block'; if(!gl) ok=false;
    if(ok){document.getElementById('success').style.display='block';this.reset();setTimeout(function(){document.getElementById('success').style.display='none'},5000);}
  };
})();
</script>